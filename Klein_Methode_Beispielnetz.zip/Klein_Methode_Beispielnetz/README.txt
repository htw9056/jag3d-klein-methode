KLEIN METHOD - EXAMPLE NETWORK WITH BUILT-IN ERRORS
===================================================
Synthetic, entirely fictitious network (no relation to real projects). The true coordinates are
in Soll_Koordinaten.txt ("Soll" = target/true) - so you can check how close a result is to the
truth. It is based on example E from the program help (GNSS, total station, levelling).
Video: see the project page https://htw9056.github.io/klein-methode/

BUILT-IN ERRORS
  1. Reading error +20 mm in the slope distance N3 -> T03
  2. Error +3 mm in the levelled height difference 0011_WP007 -> WP008
  3. Point T10 observed only once (from N6) - not overdetermined, an error there could not be detected

FILES
  Rohdaten\              files to import into JAG3D (tab separated, decimal point, angles in gon,
                         lengths in m)
  Soll_Koordinaten.txt   true coordinates used to generate the observations

IMPORT (JAG3D menu Import)
  GNSS_Festpunkte.txt      Datum points -> Datum points 3D           point, Y, X, Z geocentric
  Hoehenfestpunkte.txt     Datum points -> Datum points 1D           point, UTM32 easting, northing, height
  Raumneupunkte.txt        New points -> New points 3D               point, Y, X, Z geocentric (approximate)
  Hoehenneupunkte.txt      New points -> New points 1D               point, UTM, 0
  GNSS_Basislinien.txt     GNSS baselines -> GNSS baselines 3D       from, to, dY, dX, dZ
  Horizontalrichtungen.txt Terrestrial observations -> Direction sets
  Schraegstrecken.txt      Terrestrial observations -> Slope distances
  Zenitwinkel.txt          Terrestrial observations -> Zenith angles
  Nivellement.txt          Terrestrial observations -> Leveling data
  Import everything as it is - do not convert anything to the local system beforehand. Heights are
  already ellipsoidal; the step "import quasigeoid / convert heights" is not needed here.

PROCEDURE
  1. Create a new project and import all files as listed above.
  2. Open the "Klein method" tab and confirm the questions with the recommended answer.
  3. "Adjust network" (F5), then "Start KleinMethod" in the tab.
  4. For the dynamic and fixed stage, switch the control point groups (help, chapter 0).
  5. Compare the adjusted coordinates with Soll_Koordinaten.txt.

WHAT THE METHOD REPORTS (log, pre-check - the log is written in German)
  Naeherung | Nicht ueberbestimmt (1): T10                       (not overdetermined)
  Naeherung | Auffaellige Beobachtungen: N3 -> T03, N5 -> T08, T02 -> N1   (conspicuous observations)
  N3 -> T03 is the built-in error. N5 -> T08 and T02 -> N1 are error-free; they are only set aside
  in the robust pre-adjustment for the approximate coordinates and used normally in the adjustment.

RESULT (run with V1.00 RC3, 18 new points, deviation from the true coordinates, RMS east/north/height)
                                       free adjustment         fixed adjustment
  JAG3D, standard accuracies           2.1 / 2.6 / 1.5 mm      1.1 / 1.6 / 1.1 mm
  JAG3D with variance component est.   2.1 / 2.6 / 1.5 mm      1.1 / 1.6 / 1.1 mm
  Klein method                         0.9 / 1.5 / 1.3 mm      0.9 / 1.5 / 1.1 mm
  Danish method (c = 2.5)              1.5 / 1.1 / 1.5 mm      0.8 / 1.2 / 1.1 mm
  Network without errors, Klein method 0.9 / 1.5 / 1.2 mm      0.9 / 1.6 / 1.1 mm
  Your own runs may differ by a few tenths of a millimetre.

LIMITATIONS - PLEASE READ
  In this example the Klein method removes the effect of single gross errors. A systematic error
  that biases several observations to one point in the same way (e.g. a wrong prism constant on all
  distances to one target) is NOT yet compensated by version V1.00 RC3 - the affected distances are
  reported as conspicuous in the pre-check, but the automation does not remove the error. In a test
  with +17.5 mm on all distances to one point, that point stayed about 13 mm off; the Danish method
  solved the case. Better handling is planned for the next version. Until then: always check the
  "Auffaellige Beobachtungen" (conspicuous observations) messages.
  A point like T10 without overdetermination remains unchecked - no adjustment method can change that.

Extension of JAG3D (c) Michael Loesler, software.applied-geodesy.org - GNU GPL v3
Klein method (c) Dipl.-Ing. (FH) Stefan Klein - https://github.com/htw9056/jag3d-klein-methode
